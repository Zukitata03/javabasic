import java.util.Scanner;
class Sinhx {
public static double arctan(double x)  {
	double arctanx = x;
	double sum = x;
	for (int i = 2; i < 1000 ; i++) {
	arctanx*= (x*x);
	sum+=arctanx/(2*i-1);
	}
	return sum;
}
public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);
 double x = sc.nextDouble();
 System.out.println(arctan(x) + " " + Math.atan(x));
}	
}
